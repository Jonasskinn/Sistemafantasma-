import { useState, useEffect } from "react";
import { Zap, Activity, BarChart3, Clock, Ghost } from "lucide-react";
import { motion } from "framer-motion";

export default function GhostTestPage() {
  return (
    <div style={{ backgroundColor: "#FF1493", minHeight: "100vh", color: "white", padding: "20px" }}>
      <header style={{ textAlign: "center", padding: "40px 0" }}>
        <motion.div 
          animate={{ scale: [1, 1.2, 0.8, 1], rotate: [0, 10, -10, 0] }} 
          transition={{ duration: 2, repeat: Infinity }}
          style={{ backgroundColor: "white", width: "100px", height: "100px", borderRadius: "30px", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px", border: "6px solid black" }}
        >
          <Zap style={{ width: "50px", height: "50px", color: "#FF1493" }} />
        </motion.div>
        <h1 style={{ fontSize: "40px", fontWeight: "900", textShadow: "4px 4px 0px black" }}>LABORATÓRIO</h1>
      </header>

      <div style={{ maxWidth: "500px", margin: "0 auto", display: "grid", gap: "20px" }}>
        <div style={{ backgroundColor: "white", padding: "30px", borderRadius: "40px", border: "8px solid #C71585", textAlign: "center" }}>
          <Activity style={{ color: "#FF1493", margin: "0 auto 10px", width: "40px", height: "40px" }} />
          <h2 style={{ color: "#C71585", fontWeight: "900", fontSize: "24px" }}>TESTE DE PERFORMANCE</h2>
          <div style={{ marginTop: "20px", backgroundColor: "#FFF0F5", padding: "20px", borderRadius: "20px", border: "4px solid #FFB6C1" }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "10px" }}>
              <span style={{ color: "#C71585", fontWeight: "900" }}>LATÊNCIA</span>
              <span style={{ color: "#FF1493", fontWeight: "900" }}>3ms</span>
            </div>
            <div style={{ width: "100%", height: "20px", backgroundColor: "white", borderRadius: "10px", border: "3px solid black", overflow: "hidden" }}>
              <div style={{ width: "95%", height: "100%", backgroundColor: "#00FF00" }} />
            </div>
          </div>
        </div>

        <div style={{ backgroundColor: "white", padding: "20px", borderRadius: "30px", border: "6px solid #C71585", display: "flex", alignItems: "center", gap: "15px" }}>
          <Clock style={{ color: "#FF1493" }} />
          <span style={{ color: "#C71585", fontWeight: "900" }}>HISTÓRICO LIMPO</span>
        </div>
      </div>
    </div>
  );
}
