import { useLocation } from "wouter";
import { Ghost, Network, Gamepad2, Settings, Smartphone } from "lucide-react";
import { motion } from "framer-motion";

export default function Dashboard() {
  const [, setLocation] = useLocation();

  return (
    <div style={{ backgroundColor: "#BAE6FD", minHeight: "100vh", color: "white", padding: "20px", overflow: "hidden" }}>
      <header style={{ textAlign: "center", padding: "40px 0" }}>
        <motion.div 
          animate={{ y: [0, -20, 0] }} 
          transition={{ duration: 2, repeat: Infinity }}
          style={{ backgroundColor: "white", width: "120px", height: "120px", borderRadius: "40px", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px", border: "8px solid black" }}
        >
          <Ghost style={{ width: "60px", height: "60px", color: "#8B5CF6" }} />
        </motion.div>
        <h1 style={{ fontSize: "50px", fontWeight: "900", fontStyle: "italic", textShadow: "4px 4px 0px black", color: "#8B5CF6" }}>GHOST OS</h1>
      </header>

      <div style={{ maxWidth: "500px", margin: "0 auto", display: "grid", gap: "15px" }}>
        <button 
          onClick={() => setLocation("/games")}
          style={{ backgroundColor: "#FFFF00", padding: "25px", borderRadius: "40px", border: "8px solid black", display: "flex", alignItems: "center", gap: "20px", textAlign: "left", cursor: "pointer" }}
        >
          <div style={{ backgroundColor: "white", padding: "12px", borderRadius: "20px", border: "4px solid black" }}>
            <Gamepad2 style={{ width: "35px", height: "35px", color: "#8B5CF6" }} />
          </div>
          <span style={{ fontSize: "22px", fontWeight: "900", color: "black" }}>JOGAR AGORA</span>
        </button>

        <button 
          onClick={() => setLocation("/network")}
          style={{ backgroundColor: "#00FF00", padding: "25px", borderRadius: "40px", border: "8px solid black", display: "flex", alignItems: "center", gap: "20px", textAlign: "left", cursor: "pointer" }}
        >
          <div style={{ backgroundColor: "white", padding: "12px", borderRadius: "20px", border: "4px solid black" }}>
            <Network style={{ width: "35px", height: "35px", color: "#8B5CF6" }} />
          </div>
          <span style={{ fontSize: "22px", fontWeight: "900", color: "black" }}>GHOST NETWORK</span>
        </button>

        <button 
          onClick={() => setLocation("/devices")}
          style={{ backgroundColor: "#00BFFF", padding: "25px", borderRadius: "40px", border: "8px solid black", display: "flex", alignItems: "center", gap: "20px", textAlign: "left", cursor: "pointer" }}
        >
          <div style={{ backgroundColor: "white", padding: "12px", borderRadius: "20px", border: "4px solid black" }}>
            <Smartphone style={{ width: "35px", height: "35px", color: "#8B5CF6" }} />
          </div>
          <span style={{ fontSize: "22px", fontWeight: "900", color: "black" }}>DISPOSITIVOS</span>
        </button>

        <button 
          onClick={() => setLocation("/settings")}
          style={{ backgroundColor: "white", padding: "25px", borderRadius: "40px", border: "8px solid black", display: "flex", alignItems: "center", gap: "20px", textAlign: "left", cursor: "pointer" }}
        >
          <div style={{ backgroundColor: "#BAE6FD", padding: "12px", borderRadius: "20px", border: "4px solid black" }}>
            <Settings style={{ width: "35px", height: "35px", color: "#8B5CF6" }} />
          </div>
          <span style={{ fontSize: "22px", fontWeight: "900", color: "black" }}>CONFIGURAÇÕES</span>
        </button>
      </div>
    </div>
  );
}
