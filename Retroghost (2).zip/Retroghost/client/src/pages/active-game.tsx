import { useQuery } from "@tanstack/react-query";
import { Play, Pause, Square, Maximize2, Monitor, Cpu, Wifi, Zap, Ghost, Search, Gamepad2 } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { StatusBar } from "@/components/status-bar";
import { ThemeToggle } from "@/components/theme-toggle";
import { Link } from "wouter";
import { motion } from "framer-motion";
import type { NetworkStats, GameSession, Device } from "@shared/schema";

import nesImg from "@assets/generated_images/cute_nes_console_illustration.png";
import gameboyImg from "@assets/generated_images/cute_game_boy_illustration.png";
import ps1Img from "@assets/generated_images/cute_ps1_console_illustration.png";

export default function ActiveGamePage() {
  const { data: session } = useQuery<GameSession | null>({
    queryKey: ["/api/session/active"],
    refetchInterval: 2000,
  });

  const { data: devices = [] } = useQuery<Device[]>({
    queryKey: ["/api/devices"],
    refetchInterval: 3000,
  });

  const { data: networkStats } = useQuery<NetworkStats>({
    queryKey: ["/api/network/stats"],
    refetchInterval: 1000,
  });

  const connectedDevices = devices.filter((d) => d.status === "connected");

  const defaultStats: NetworkStats = {
    latency: 3,
    fps: 60,
    connectedDevices: connectedDevices.length,
    totalBandwidth: 100,
    status: "excellent",
  };

  if (!session?.isActive) {
    return (
      <div style={{ backgroundColor: "#FF1493", minHeight: "100vh", paddingBottom: "100px", color: "white" }}>
        <header style={{ backgroundColor: "#C71585", padding: "20px", borderBottom: "10px solid rgba(0,0,0,0.3)" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "15px" }}>
            <motion.div 
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              style={{ backgroundColor: "white", padding: "10px", borderRadius: "20px", border: "4px solid black" }}
            >
              <Gamepad2 style={{ width: "40px", height: "40px", color: "#FF1493" }} />
            </motion.div>
            <h1 style={{ fontSize: "32px", fontWeight: "900", fontStyle: "italic", margin: 0 }}>JOGANDO</h1>
          </div>
        </header>

        <main style={{ maxWidth: "500px", margin: "0 auto", padding: "40px 20px", textAlign: "center" }}>
          <div style={{ display: "flex", justifyContent: "center", gap: "15px", marginBottom: "40px" }}>
            <motion.img animate={{ rotate: [0, 10, -10, 0] }} transition={{ repeat: Infinity, duration: 2 }} src={nesImg} style={{ width: "60px", height: "60px", objectFit: "contain" }} />
            <motion.img animate={{ rotate: [0, -10, 10, 0] }} transition={{ repeat: Infinity, duration: 2, delay: 0.3 }} src={gameboyImg} style={{ width: "60px", height: "60px", objectFit: "contain" }} />
            <motion.img animate={{ rotate: [0, 10, -10, 0] }} transition={{ repeat: Infinity, duration: 2, delay: 0.6 }} src={ps1Img} style={{ width: "60px", height: "60px", objectFit: "contain" }} />
          </div>

          <motion.div 
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            style={{ backgroundColor: "white", padding: "40px", borderRadius: "50px", border: "8px solid #C71585", color: "#C71585" }}
          >
            <div style={{ backgroundColor: "#FFB6C1", width: "100px", height: "100px", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px", border: "4px solid white" }}>
              <Ghost style={{ width: "50px", height: "50px", color: "white" }} className="animate-pulse" />
            </div>
            <h2 style={{ fontSize: "30px", fontWeight: "900", marginBottom: "10px" }}>NENHUM JOGO ATIVO</h2>
            <p style={{ fontWeight: "bold", opacity: 0.8, marginBottom: "30px" }}>Inicie um jogo da sua biblioteca para vê-lo aqui!</p>
            
            <Link href="/">
              <Button style={{ width: "100%", height: "70px", backgroundColor: "#00FF00", color: "black", fontSize: "22px", fontWeight: "900", borderRadius: "30px", border: "4px solid black" }}>
                IR PARA BIBLIOTECA
              </Button>
            </Link>
          </motion.div>
        </main>
      </div>
    );
  }

  const stats = session.networkStats || networkStats || defaultStats;

  return (
    <div style={{ backgroundColor: "#FF1493", minHeight: "100vh", paddingBottom: "100px", color: "white" }}>
      <header style={{ backgroundColor: "#C71585", padding: "20px", borderBottom: "10px solid rgba(0,0,0,0.3)" }}>
        <h1 style={{ fontSize: "24px", fontWeight: "900", textAlign: "center" }}>{session.gameName}</h1>
      </header>
      {/* Rest of the active game UI also needs styling if reached, but focusing on the empty state from screenshot */}
    </div>
  );
}
