import { useQuery } from "@tanstack/react-query";
import { Smartphone, Tv, Monitor as MonitorIcon, Router, Wifi, Globe, Search, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import type { Device, NetworkStats } from "@shared/schema";

export default function DevicesPage() {
  const { data: devices = [], isLoading } = useQuery<Device[]>({
    queryKey: ["/api/devices"],
  });

  const connectedDevices = devices.filter((d) => d.status === "connected");

  const getDeviceTypeIcon = (type: string) => {
    switch (type) {
      case "phone": return Smartphone;
      case "tv": return Tv;
      case "pc": return MonitorIcon;
      case "router": return Router;
      default: return MonitorIcon;
    }
  };

  return (
    <div style={{ backgroundColor: "#FF1493", minHeight: "100vh", color: "white", padding: "20px" }}>
      <header style={{ textAlign: "center", padding: "40px 0" }}>
        <motion.div 
          animate={{ scale: [1, 1.1, 1] }} 
          transition={{ duration: 2, repeat: Infinity }}
          style={{ backgroundColor: "white", width: "100px", height: "100px", borderRadius: "30px", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px", border: "6px solid black" }}
        >
          <Smartphone style={{ width: "50px", height: "50px", color: "#FF1493" }} />
        </motion.div>
        <h1 style={{ fontSize: "40px", fontWeight: "900", textShadow: "4px 4px 0px black" }}>DISPOSITIVOS</h1>
      </header>

      <div style={{ maxWidth: "500px", margin: "0 auto", display: "grid", gap: "20px" }}>
        <div style={{ backgroundColor: "white", padding: "20px", borderRadius: "40px", border: "8px solid #C71585", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
          {["phone", "tv", "pc", "router"].map((type) => {
            const count = devices.filter((d) => d.deviceType === type && d.status === "connected").length;
            const Icon = getDeviceTypeIcon(type);
            const labels = { phone: "Celulares", tv: "Smart TVs", pc: "PCs", router: "Roteadores" };
            return (
              <div key={type} style={{ backgroundColor: "#FFF0F5", padding: "15px", borderRadius: "20px", textAlign: "center", border: "4px solid #FFB6C1" }}>
                <Icon style={{ color: "#FF1493", margin: "0 auto 5px" }} />
                <div style={{ color: "#C71585", fontSize: "20px", fontWeight: "900" }}>{count}</div>
                <div style={{ color: "#FF69B4", fontSize: "10px", fontWeight: "bold" }}>{labels[type as keyof typeof labels]}</div>
              </div>
            );
          })}
        </div>

        <div style={{ backgroundColor: "#FFB6C1", padding: "20px", borderRadius: "30px", border: "6px solid white", display: "flex", alignItems: "center", gap: "15px" }}>
          <Wifi className="animate-pulse" style={{ color: "white" }} />
          <span style={{ fontWeight: "900", fontSize: "14px" }}>BUSCANDO AUTOMATICAMENTE NA REDE WIFI</span>
        </div>

        {connectedDevices.map((device) => (
          <div key={device.id} style={{ backgroundColor: "white", padding: "20px", borderRadius: "30px", border: "6px solid #C71585", display: "flex", alignItems: "center", gap: "15px" }}>
            <div style={{ backgroundColor: "#FF1493", padding: "10px", borderRadius: "15px" }}>
              <Smartphone style={{ color: "white" }} />
            </div>
            <div>
              <div style={{ color: "#C71585", fontWeight: "900" }}>{device.name}</div>
              <div style={{ color: "#FF69B4", fontSize: "12px" }}>{device.ipAddress}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
