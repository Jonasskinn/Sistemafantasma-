import { useState, useRef, useEffect } from "react";
import { Ghost, Upload, Play, Trash2, Loader2, Gamepad2, X, Languages, Search } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { StatusBar } from "@/components/status-bar";
import { ThemeToggle } from "@/components/theme-toggle";
import { useToast } from "@/hooks/use-toast";
import { EmulatorPlayer, detectCore } from "@/components/emulator-player";

import nesImg from "@assets/generated_images/cute_nes_console_illustration.png";
import snesImg from "@assets/generated_images/cute_snes_console_illustration.png";
import ps1Img from "@assets/generated_images/cute_ps1_console_illustration.png";
import gameboyImg from "@assets/generated_images/cute_game_boy_illustration.png";
import megadriveImg from "@assets/generated_images/cute_mega_drive_illustration.png";
import n64Img from "@assets/generated_images/cute_n64_console_illustration.png";

interface UploadedRom {
  id: string;
  filename: string;
  name: string;
  core: string;
  size: number;
  url: string;
}

const translations = {
  pt: {
    title: "GHOST GAMES",
    library: "BIBLIOTECA",
    addRom: "ADICIONAR JOGO",
    noGames: "NENHUM JOGO AQUI",
    clickToAdd: "TOQUE PARA ADICIONAR!",
    romAdded: "SUCESSO!",
    romReady: "PRONTO!",
    errorUpload: "ERRO!",
    errorProcess: "ARQUIVO INVÁLIDO.",
    chooseConsole: "QUAL CONSOLE?",
  },
  en: {
    title: "GHOST GAMES",
    library: "LIBRARY",
    addRom: "ADD GAME",
    noGames: "NO GAMES YET",
    clickToAdd: "TAP TO ADD!",
    romAdded: "SUCCESS!",
    romReady: "READY!",
    errorUpload: "ERROR!",
    errorProcess: "INVALID FILE.",
    chooseConsole: "WHICH CONSOLE?",
  }
};

const CORE_LABELS: Record<string, string> = {
  nes: "NES",
  snes: "SNES",
  gb: "GAME BOY",
  gbc: "GB COLOR",
  gba: "GB ADVANCE",
  n64: "N64",
  psx: "PS1",
  segaMD: "MEGA DRIVE",
  nds: "NINTENDO DS",
};

const CORE_IMAGES: Record<string, string> = {
  nes: nesImg,
  snes: snesImg,
  gb: gameboyImg,
  gbc: gameboyImg,
  gba: gameboyImg,
  n64: n64Img,
  psx: ps1Img,
  segaMD: megadriveImg,
  nds: gameboyImg,
};

function formatSize(bytes: number): string {
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + " KB";
  return (bytes / (1024 * 1024)).toFixed(1) + " MB";
}

const STORAGE_KEY = "ghost-roms-list";

interface PendingFile {
  file: File;
  name: string;
  detectedCore: string;
}

export default function GhostGamesPage() {
  const [lang, setLang] = useState<'pt' | 'en'>('pt');
  const t = translations[lang];
  const [roms, setRoms] = useState<UploadedRom[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [playingRom, setPlayingRom] = useState<UploadedRom | null>(null);
  const [pendingFile, setPendingFile] = useState<PendingFile | null>(null);
  const [selectedCore, setSelectedCore] = useState<string>("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try { setRoms(JSON.parse(saved)); } catch (e) { console.error(e); }
    }
  }, []);

  const saveRoms = (newRoms: UploadedRom[]) => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newRoms));
    setRoms(newRoms);
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const detectedCore = detectCore(file.name);
    setPendingFile({ file, name: file.name.replace(/\.[^/.]+$/, ""), detectedCore });
    setSelectedCore(detectedCore);
  };

  const handleCoreSelected = async (coreChoice: string) => {
    if (!pendingFile) return;
    setIsUploading(true);
    setUploadProgress(20);
    try {
      const { file, name } = pendingFile;
      const formData = new FormData();
      formData.append("rom", file);
      formData.append("name", name);
      formData.append("core", coreChoice);
      const response = await fetch("/api/roms/upload", { method: "POST", body: formData });
      if (!response.ok) throw new Error("Upload failed");
      const rom: UploadedRom = await response.json();
      saveRoms([...roms, rom]);
      toast({ title: t.romAdded, description: `${name} ${t.romReady}` });
    } catch (error) {
      toast({ title: t.errorUpload, description: t.errorProcess, variant: "destructive" });
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
      setPendingFile(null);
    }
  };

  const handlePlayGame = (rom: UploadedRom) => {
    const fullRomUrl = rom.url.startsWith("http") ? rom.url : window.location.origin + rom.url;
    setPlayingRom({ ...rom, url: fullRomUrl });
  };

  const handleDeleteGame = async (rom: UploadedRom) => {
    try {
      await fetch(`/api/roms/${rom.filename}`, { method: "DELETE" });
      saveRoms(roms.filter((r) => r.id !== rom.id));
    } catch (e) { console.error(e); }
  };

  return (
    <div style={{ backgroundColor: "#BAE6FD", minHeight: "100vh", paddingBottom: "100px", color: "white" }}>
      <header style={{ backgroundColor: "#8B5CF6", padding: "20px", borderBottom: "10px solid rgba(0,0,0,0.3)" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", maxWidth: "500px", margin: "0 auto" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "15px" }}>
            <motion.div 
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 2, repeat: Infinity }}
              style={{ backgroundColor: "white", padding: "10px", borderRadius: "20px", border: "4px solid black" }}
            >
              <Ghost style={{ width: "40px", height: "40px", color: "#8B5CF6" }} />
            </motion.div>
            <h1 style={{ fontSize: "40px", fontWeight: "900", fontStyle: "italic", margin: 0 }}>GHOST</h1>
          </div>
          <Button onClick={() => setLang(lang === 'pt' ? 'en' : 'pt')} style={{ backgroundColor: "#FFFF00", color: "black", fontWeight: "900", border: "3px solid black" }}>{lang === 'pt' ? 'EN' : 'PT'}</Button>
        </div>
      </header>

      <main style={{ maxWidth: "500px", margin: "0 auto", padding: "20px", display: "flex", flexDirection: "column", gap: "40px" }}>
        <div style={{ display: "flex", justifyContent: "center", gap: "15px", marginBottom: "-20px" }}>
          <motion.img animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 1.5 }} src={nesImg} style={{ width: "50px", height: "50px", objectFit: "contain" }} />
          <motion.img animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 1.5, delay: 0.2 }} src={gameboyImg} style={{ width: "50px", height: "50px", objectFit: "contain" }} />
          <motion.img animate={{ y: [0, -5, 0] }} transition={{ repeat: Infinity, duration: 1.5, delay: 0.4 }} src={ps1Img} style={{ width: "50px", height: "50px", objectFit: "contain" }} />
        </div>

        <motion.div 
          initial={{ scale: 0.8 }}
          animate={{ scale: 1 }}
          style={{ backgroundColor: "#F0F9FF", padding: "40px", borderRadius: "60px", border: "10px solid white", textAlign: "center" }}
        >
          <motion.div 
            animate={{ scale: [1, 1.1, 1] }}
            transition={{ duration: 1.5, repeat: Infinity }}
            style={{ width: "120px", height: "120px", backgroundColor: "white", borderRadius: "50%", margin: "0 auto 20px", display: "flex", alignItems: "center", justifyContent: "center", border: "8px solid #8B5CF6" }}
          >
            <Upload style={{ width: "60px", height: "60px", color: "#8B5CF6" }} />
          </motion.div>
          <h2 style={{ fontSize: "40px", fontWeight: "900", marginBottom: "10px", color: "#8B5CF6" }}>{t.addRom}</h2>
          <Button onClick={() => fileInputRef.current?.click()} style={{ width: "100%", height: "80px", backgroundColor: "#FFFF00", color: "black", fontSize: "30px", fontWeight: "900", borderRadius: "40px", border: "6px solid black" }}>ESCOLHER</Button>
          <input ref={fileInputRef} type="file" className="hidden" onChange={handleFileSelect} />
        </motion.div>

        <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
          <AnimatePresence>
            {roms.length === 0 ? (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                style={{ backgroundColor: "white", padding: "40px", borderRadius: "40px", border: "8px solid #8B5CF6", textAlign: "center" }}
              >
                <Search style={{ width: "80px", height: "80px", color: "#BAE6FD", margin: "0 auto 20px" }} />
                <h3 style={{ color: "#8B5CF6", fontSize: "24px", fontWeight: "900" }}>{t.noGames}</h3>
                <p style={{ color: "#8B5CF6", opacity: 0.7, fontWeight: "bold" }}>{t.clickToAdd}</p>
              </motion.div>
            ) : (
              roms.map((rom) => (
                <motion.div 
                  key={rom.id} 
                  initial={{ x: -50, opacity: 0 }}
                  animate={{ x: 0, opacity: 1 }}
                  style={{ backgroundColor: "white", padding: "20px", borderRadius: "40px", border: "8px solid #8B5CF6", display: "flex", flexDirection: "column", gap: "20px" }}
                >
                  <div style={{ display: "flex", alignItems: "center", gap: "20px" }}>
                    <div style={{ width: "100px", height: "100px", backgroundColor: "#BAE6FD", borderRadius: "20px", padding: "10px", border: "4px solid white" }}>
                      <img src={CORE_IMAGES[rom.core] || nesImg} style={{ width: "100%", height: "100%", objectFit: "contain" }} />
                    </div>
                    <div>
                      <h4 style={{ fontSize: "24px", fontWeight: "900", color: "#8B5CF6", margin: 0 }}>{rom.name}</h4>
                      <span style={{ backgroundColor: "#8B5CF6", color: "white", padding: "5px 15px", borderRadius: "20px", fontWeight: "900", fontSize: "14px" }}>{CORE_LABELS[rom.core]}</span>
                    </div>
                  </div>
                  <div style={{ display: "flex", gap: "10px" }}>
                    <Button onClick={() => handlePlayGame(rom)} style={{ flex: 1, height: "70px", backgroundColor: "#00FF00", color: "black", fontSize: "24px", fontWeight: "900", borderRadius: "25px", border: "4px solid black" }}>JOGAR</Button>
                    <Button onClick={() => handleDeleteGame(rom)} style={{ width: "70px", height: "70px", backgroundColor: "#FF0000", color: "white", borderRadius: "25px", border: "4px solid black" }}><Trash2 /></Button>
                  </div>
                </motion.div>
              ))
            )}
          </AnimatePresence>
        </div>
      </main>

      <AnimatePresence>
        {pendingFile && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            style={{ position: "fixed", inset: 0, backgroundColor: "rgba(0,0,0,0.9)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", padding: "20px" }}
          >
            <motion.div 
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              style={{ backgroundColor: "#BAE6FD", padding: "30px", borderRadius: "50px", border: "10px solid white", width: "100%", maxWidth: "450px" }}
            >
              <h3 style={{ fontSize: "36px", fontWeight: "900", textAlign: "center", marginBottom: "30px", color: "#8B5CF6" }}>{t.chooseConsole}</h3>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px", maxHeight: "400px", overflowY: "auto" }}>
                {Object.keys(CORE_LABELS).map((core) => (
                  <button key={core} onClick={() => handleCoreSelected(core)} style={{ backgroundColor: "white", padding: "20px", borderRadius: "30px", border: "6px solid #8B5CF6", display: "flex", flexDirection: "column", alignItems: "center", gap: "10px" }}>
                    <img src={CORE_IMAGES[core] || nesImg} style={{ width: "80px", height: "80px", objectFit: "contain" }} />
                    <span style={{ fontWeight: "900", color: "#8B5CF6" }}>{CORE_LABELS[core]}</span>
                  </button>
                ))}
              </div>
              <Button onClick={() => setPendingFile(null)} style={{ width: "100%", height: "60px", marginTop: "20px", backgroundColor: "black", color: "white", borderRadius: "20px" }}>FECHAR</Button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {playingRom && (
        <EmulatorPlayer romUrl={playingRom.url} romName={playingRom.name} core={playingRom.core} onClose={() => setPlayingRom(null)} />
      )}
    </div>
  );
}
