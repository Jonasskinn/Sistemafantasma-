import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Game } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

export default function Home() {
  const { data: games, isLoading } = useQuery<Game[]>({
    queryKey: ["/api/games"],
  });

  return (
    <div className="min-h-screen bg-background p-8">
      <header className="mb-8 text-center">
        <h1 className="text-4xl font-bold text-primary mb-2 tracking-tight">Retro DS</h1>
        <p className="text-muted-foreground">Sua coleção de jogos retrô clássicos</p>
      </header>

      <main className="max-w-6xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {isLoading ? (
            Array(3).fill(0).map((_, i) => (
              <Card key={i} className="overflow-hidden border-border">
                <Skeleton className="h-48 w-full" />
                <CardHeader>
                  <Skeleton className="h-6 w-3/4" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-4 w-full" />
                </CardContent>
              </Card>
            ))
          ) : (
            games?.map((game) => (
              <Card key={game.id} className="hover-elevate transition-all border-border overflow-hidden">
                <div 
                  className="h-48 bg-cover bg-center"
                  style={{ backgroundImage: `url(${game.imageUrl})` }}
                />
                <CardHeader>
                  <CardTitle className="text-xl">{game.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground mb-4 line-clamp-2">{game.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="px-2 py-1 bg-accent text-accent-foreground text-xs rounded-md">
                      {game.genre}
                    </span>
                    {game.isRetro && (
                      <span className="text-xs text-primary font-semibold uppercase tracking-wider">
                        Retro Classico
                      </span>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </main>
    </div>
  );
}
