import { useQuery } from "@tanstack/react-query";
import { Ghost, Network, Server, Smartphone, Activity } from "lucide-react";
import { motion } from "framer-motion";
import type { NetworkStats } from "@shared/schema";

export default function GhostNetwork() {
  const { data: stats } = useQuery<NetworkStats>({
    queryKey: ["/api/network/stats"],
    refetchInterval: 3000,
  });

  return (
    <div style={{ backgroundColor: "#BAE6FD", minHeight: "100vh", color: "white", padding: "20px" }}>
      <header style={{ textAlign: "center", padding: "40px 0" }}>
        <motion.div 
          animate={{ y: [0, -20, 0], rotate: [0, 10, -10, 0] }} 
          transition={{ duration: 3, repeat: Infinity }}
          style={{ backgroundColor: "white", width: "100px", height: "100px", borderRadius: "30px", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px", border: "6px solid black" }}
        >
          <Network style={{ width: "50px", height: "50px", color: "#8B5CF6" }} />
        </motion.div>
        <h1 style={{ fontSize: "40px", fontWeight: "900", textShadow: "4px 4px 0px black", color: "#8B5CF6" }}>REDE GHOST</h1>
      </header>

      <div style={{ maxWidth: "500px", margin: "0 auto", display: "grid", gap: "20px" }}>
        <div style={{ backgroundColor: "white", padding: "30px", borderRadius: "40px", border: "8px solid #8B5CF6", textAlign: "center" }}>
          <h2 style={{ color: "#8B5CF6", fontWeight: "900", fontSize: "24px", marginBottom: "20px" }}>ESTADO DA REDE</h2>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "20px" }}>
            <div style={{ backgroundColor: "#F0F9FF", padding: "20px", borderRadius: "20px", border: "4px solid #BAE6FD" }}>
              <Smartphone style={{ color: "#8B5CF6", margin: "0 auto 10px" }} />
              <div style={{ color: "#8B5CF6", fontWeight: "900", fontSize: "24px" }}>{stats?.connectedDevices || 0}</div>
              <div style={{ color: "#8B5CF6", opacity: 0.7, fontSize: "12px", fontWeight: "bold" }}>DISPOSITIVOS</div>
            </div>
            <div style={{ backgroundColor: "#F0F9FF", padding: "20px", borderRadius: "20px", border: "4px solid #BAE6FD" }}>
              <Activity style={{ color: "#8B5CF6", margin: "0 auto 10px" }} />
              <div style={{ color: "#8B5CF6", fontWeight: "900", fontSize: "24px" }}>{stats?.latency || 0}ms</div>
              <div style={{ color: "#8B5CF6", opacity: 0.7, fontSize: "12px", fontWeight: "bold" }}>LATÊNCIA</div>
            </div>
          </div>
        </div>

        <motion.div 
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
          style={{ backgroundColor: "white", padding: "20px", borderRadius: "40px", border: "8px solid #8B5CF6", display: "flex", alignItems: "center", gap: "20px" }}
        >
          <div style={{ backgroundColor: "#8B5CF6", padding: "10px", borderRadius: "15px" }}>
            <Ghost style={{ color: "white" }} className="animate-pulse" />
          </div>
          <span style={{ color: "#8B5CF6", fontWeight: "900" }}>SINALIZAÇÃO ATIVA</span>
        </motion.div>
      </div>
    </div>
  );
}
