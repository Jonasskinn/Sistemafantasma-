import { motion } from "framer-motion";
import { Download, ExternalLink, Gamepad2, Globe } from "lucide-react";
import { Button } from "@/components/ui/button";

// Imagens ilustrativas geradas (nomes de arquivos corrigidos para snake_case)
import retroGamingIllustration from "@assets/generated_images/retro_gaming_illustration_with_portuguese_flag_colors.png";
import gameCollectionIllustration from "@assets/generated_images/animated_style_retro_game_collection_illustration.png";

export default function PlayPage() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1
    }
  };

  return (
    <div className="min-h-screen bg-[#BAE6FD] p-6 pb-24 text-black font-['Press_Start_2P']">
      <header className="max-w-4xl mx-auto text-center mb-12">
        <motion.h1 
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="text-2xl md:text-4xl font-black mb-4 text-[#8B5CF6] italic drop-shadow-[2px_2px_0px_white]"
        >
          SISTEMA FANTASMA
        </motion.h1>
        <p className="text-[10px] opacity-70 leading-relaxed uppercase">BIBLIOTECA DE ROMS EM PORTUGUÊS</p>
      </header>

      <motion.main 
        variants={containerVariants}
        initial="hidden"
        animate="visible"
        className="max-w-4xl mx-auto space-y-8"
      >
        {/* Card Principal */}
        <motion.section 
          variants={itemVariants}
          className="bg-white p-6 md:p-10 rounded-lg border-8 border-black shadow-[10px_10px_0px_rgba(0,0,0,0.2)] text-center relative overflow-hidden"
        >
          {/* Decoração Pixel Art */}
          <div className="absolute -top-4 -right-4 w-24 h-24 opacity-20 pointer-events-none">
            <img src={retroGamingIllustration} alt="Deco" className="w-full h-full object-contain pixelated" />
          </div>
          
          <div className="relative z-10">
            <div className="bg-[#FFFF00] w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 border-4 border-black shadow-[4px_4px_0px_black] animate-bounce">
              <Download className="w-10 h-10 text-black" />
            </div>
            
            <h2 className="text-sm md:text-xl font-bold mb-6 leading-relaxed uppercase">
              BAIXE AQUI SUAS ROMS DE JOGOS <span className="text-[#00FF00]">EM PORTUGUÊS</span>!
            </h2>
            
            <p className="text-[8px] md:text-[10px] leading-relaxed opacity-80 mb-10 px-4 uppercase">
              ACESSE O MELHOR PORTAL DE TRADUÇÕES E ROMS DO BRASIL. 
              BAIXE O ARQUIVO E USE NO NOSSO EMULADOR!
            </p>

            <div className="grid gap-4 max-w-md mx-auto">
              <Button asChild className="bg-[#00FF00] hover:bg-[#00CC00] text-black border-4 border-black h-16 text-[12px] shadow-[6px_6px_0px_black] active:shadow-none active:translate-x-[2px] active:translate-y-[2px] group">
                <a href="https://romsportugues.com/" target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="mr-2 h-5 w-5 group-hover:rotate-12 transition-transform" />
                  ACESSAR ROMS PORTUGUÊS
                </a>
              </Button>
              
              <Button asChild variant="outline" className="bg-[#FFFF00] hover:bg-[#e6e600] text-black border-4 border-black h-16 text-[12px] shadow-[6px_6px_0px_black] active:shadow-none active:translate-x-[2px] active:translate-y-[2px]">
                <a href="/">
                  <Gamepad2 className="mr-2 h-5 w-5" />
                  IR PARA O EMULADOR
                </a>
              </Button>
            </div>
          </div>
        </motion.section>

        {/* Galeria Ilustrativa */}
        <motion.div 
          variants={itemVariants}
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
        >
          <div className="bg-white p-4 rounded-lg border-4 border-black shadow-[4px_4px_0px_black] flex items-center gap-4">
            <div className="w-20 h-20 bg-gray-100 border-2 border-black overflow-hidden shrink-0">
              <img src={retroGamingIllustration} alt="Retro" className="w-full h-full object-cover pixelated" />
            </div>
            <div>
              <h3 className="text-[10px] font-bold mb-2 uppercase">CLÁSSICOS TRADUZIDOS</h3>
              <p className="text-[8px] opacity-70 uppercase">JOGUE RPGs E AVENTURAS COM TEXTOS EM PT-BR.</p>
            </div>
          </div>

          <div className="bg-white p-4 rounded-lg border-4 border-black shadow-[4px_4px_0px_black] flex items-center gap-4">
            <div className="w-20 h-20 bg-gray-100 border-2 border-black overflow-hidden shrink-0">
              <img src={gameCollectionIllustration} alt="Collection" className="w-full h-full object-cover pixelated" />
            </div>
            <div>
              <h3 className="text-[10px] font-bold mb-2 uppercase">MILHARES DE OPÇÕES</h3>
              <p className="text-[8px] opacity-70 uppercase">SUPORTE PARA NES, SNES, GBA, NDS E MAIS.</p>
            </div>
          </div>
        </motion.div>

        {/* Footer info */}
        <motion.div variants={itemVariants} className="text-center">
          <div className="inline-flex items-center gap-2 bg-black text-white px-4 py-2 rounded-full text-[8px] uppercase">
            <Globe className="w-3 h-3 text-[#00FF00]" />
            CONECTADO AO GHOST NETWORK
          </div>
        </motion.div>
      </motion.main>
    </div>
  );
}
