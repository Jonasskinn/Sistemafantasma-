import { motion } from "framer-motion";
import { ExternalLink, Tag, ShoppingBag, Gift, Sparkles, TrendingUp } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

export default function OffersPage() {
  const monetizationLink = "https://otieu.com/4/10402648";
  const shopLink = "https://collshp.com/shopbonus";

  const categories = [
    { name: "Apps", icon: Sparkles, color: "text-purple-400" },
    { name: "Lojas", icon: ShoppingBag, color: "text-blue-400" },
    { name: "Ofertas", icon: Tag, color: "text-green-400" },
    { name: "Acessórios", icon: Gift, color: "text-pink-400" },
  ];

  const offers = [
    {
      title: "Super Ofertas de Apps",
      description: "Descubra os aplicativos mais populares e ganhe recompensas.",
      image: "https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?auto=format&fit=crop&q=80&w=400",
      tag: "Destaque",
      link: monetizationLink
    },
    {
      title: "Loja de Acessórios Gamer",
      description: "Os melhores acessórios e jogos com descontos exclusivos.",
      image: "https://images.unsplash.com/photo-1542751371-adc38448a05e?auto=format&fit=crop&q=80&w=400",
      tag: "Promoção",
      link: shopLink
    },
    {
      title: "Cupons Diários",
      description: "Economize em todas as suas compras online hoje mesmo.",
      image: "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&q=80&w=400",
      tag: "Grátis",
      link: monetizationLink
    }
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white p-6 pb-24">
      <header className="max-w-4xl mx-auto text-center mb-12">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          className="inline-block p-3 rounded-2xl bg-primary/20 border-2 border-primary mb-6"
        >
          <TrendingUp className="w-8 h-8 text-primary" />
        </motion.div>
        <motion.h1 
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="text-4xl md:text-6xl font-black italic text-primary mb-4"
        >
          LINK DE OFERTAS
        </motion.h1>
        <p className="text-xl text-gray-400">
          As melhores oportunidades selecionadas para você.
        </p>
      </header>

      <div className="max-w-4xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
        {categories.map((cat, i) => (
          <motion.div
            key={cat.name}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="bg-[#1a1a24] p-4 rounded-2xl border-2 border-white/5 flex flex-col items-center gap-2"
          >
            <cat.icon className={`w-6 h-6 ${cat.color}`} />
            <span className="text-sm font-bold uppercase">{cat.name}</span>
          </motion.div>
        ))}
      </div>

      <main className="max-w-4xl mx-auto space-y-6">
        {offers.map((offer, i) => (
          <motion.div
            key={offer.title}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="bg-[#1a1a24] border-4 border-primary hover:border-[#FFFF00] transition-colors overflow-hidden">
              <CardContent className="p-0 flex flex-col md:flex-row">
                <div className="md:w-1/3 h-48 md:h-auto overflow-hidden">
                  <img src={offer.image} alt={offer.title} className="w-full h-full object-cover" />
                </div>
                <div className="p-6 flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start mb-2">
                      <span className="px-3 py-1 bg-primary/20 text-primary text-xs font-bold rounded-full border border-primary">
                        {offer.tag}
                      </span>
                    </div>
                    <h2 className="text-2xl font-bold mb-2 uppercase text-white">{offer.title}</h2>
                    <p className="text-gray-400 text-sm mb-6">{offer.description}</p>
                  </div>
                  <Button 
                    asChild
                    className="w-full bg-primary hover:bg-primary/90 text-white font-black py-6 rounded-2xl border-b-4 border-black active:border-b-0 flex items-center gap-2"
                  >
                    <a href={offer.link} target="_blank" rel="noopener noreferrer">
                      VER OFERTA <ExternalLink className="w-5 h-5" />
                    </a>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </main>

      <section className="max-w-4xl mx-auto mt-12 p-8 bg-primary rounded-3xl border-4 border-black text-white text-center">
        <h3 className="text-2xl font-black mb-4 uppercase italic">Não perca nada!</h3>
        <p className="font-bold mb-6">Confira todas as nossas ofertas agora mesmo.</p>
        <Button 
          asChild
          variant="outline"
          className="bg-white text-black hover:bg-gray-100 font-black px-8 py-6 rounded-2xl border-b-4 border-gray-300"
        >
          <a href={monetizationLink} target="_blank" rel="noopener noreferrer">
            ACESSAR LINK DE OFERTAS
          </a>
        </Button>
      </section>
    </div>
  );
}
