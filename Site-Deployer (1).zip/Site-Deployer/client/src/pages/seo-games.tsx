import { useState } from "react";
import { motion } from "framer-motion";
import { Gamepad2, Trophy, Star, Zap, Clock, Users, Languages } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const translations = {
  pt: {
    title: "JOGAR JOGOS RETRÔ GRÁTIS",
    subtitle: "A melhor plataforma para jogar clássicos de Game Boy, SNES, PS1 e mais diretamente no seu navegador.",
    playNow: "JOGAR AGORA",
    whyTitle: "POR QUE JOGAR NO SISTEMA FANTASMA?",
    noDownload: "Sem Download",
    noDownloadDesc: "Carregamento instantâneo via Ghost Network.",
    saveState: "Save State",
    saveStateDesc: "Salve seu progresso a qualquer momento.",
    p2p: "Multiplayer P2P",
    p2pDesc: "Jogue com amigos na mesma rede.",
    free: "Grátis para Sempre",
    freeDesc: "Acesso ilimitado aos melhores jogos retro.",
    aboutTitle: "Sobre Emulação Online",
    aboutText: "O Sistema Fantasma é um emulador online avançado focado em preservar a história dos videogames. Nossa tecnologia permite jogar jogos de Game Boy Advance, Color, NES, SNES, PlayStation 1, Mega Drive, Nintendo 64 e Nintendo DS sem a necessidade de instalar nada. Basta carregar sua ROM e começar a diversão clássica. Otimizado para mobile e desktop, oferecemos a melhor experiência de jogo retrô grátis da internet.",
    bestEmulators: "Melhores Emuladores 2026",
    howToPlay: "Como Jogar Retro Games Online",
    legalSafe: "Legal e Seguro",
    consoleGuides: "Guias por Console",
    lang: "EN",
    gameboy: "Jogue clássicos como Pokémon e Zelda",
    snes: "Os melhores do SNES no seu navegador",
    ps1: "Reviva a era 3D do PSX",
    megadrive: "Sonic e muito mais do SEGA",
    n64: "A revolução do 64 bits",
    nds: "Clássicos do Nintendo DS em duas telas",
    nes: "Onde tudo começou",
    retroarch: "Tecnologia RetroArch Web",
    multiplayer: "Jogue Multiplayer Online",
    saveGames: "Salve seu progresso na nuvem",
    bestGraphics: "Gráficos em HD e 4K"
  },
  en: {
    title: "PLAY FREE RETRO GAMES",
    subtitle: "The best platform to play Game Boy, SNES, PS1 classics and more directly in your browser.",
    playNow: "PLAY NOW",
    whyTitle: "WHY PLAY ON GHOST SYSTEM?",
    noDownload: "No Download",
    noDownloadDesc: "Instant loading via Ghost Network.",
    saveState: "Save State",
    saveStateDesc: "Save your progress at any time.",
    p2p: "P2P Multiplayer",
    p2pDesc: "Play with friends on the same network.",
    free: "Free Forever",
    freeDesc: "Unlimited access to the best retro games.",
    aboutTitle: "About Online Emulation",
    aboutText: "Ghost System is an advanced online emulator focused on preserving videogame history. Our technology allows you to play Game Boy Advance, Color, NES, SNES, PlayStation 1, Mega Drive, Nintendo 64, and Nintendo DS games without installing anything. Just load your ROM and start the classic fun. Optimized for mobile and desktop, we offer the best free retro gaming experience on the internet.",
    bestEmulators: "Best Emulators 2026",
    howToPlay: "How to Play Retro Games Online",
    legalSafe: "Legal and Safe",
    consoleGuides: "Console Guides",
    lang: "PT",
    gameboy: "Play classics like Pokémon and Zelda",
    snes: "The best of SNES in your browser",
    ps1: "Relive the 3D era of PSX",
    megadrive: "Sonic and more from SEGA",
    n64: "The 64-bit revolution",
    nds: "Nintendo DS classics on dual screens",
    nes: "Where it all started",
    retroarch: "RetroArch Web Technology",
    multiplayer: "Play Online Multiplayer",
    saveGames: "Save your progress in the cloud",
    bestGraphics: "HD and 4K Graphics"
  }
};

export default function SeoGamesPage() {
  const [lang, setLang] = useState<'pt' | 'en'>('pt');
  const t = translations[lang];

  const consoles = [
    { name: "Game Boy", desc: t.gameboy, keywords: "jogos game boy gratis, emulador gb online, emulador game boy advance, gba emulator online, game boy color emulator, retroarch gameboy, play pokemon online free, zelda gba online" },
    { name: "Super Nintendo", desc: t.snes, keywords: "jogar snes online, snes gratis, super nintendo emulator, snes emulator android, snes games online, retroarch snes, mario world online snes, donkey kong online gratis" },
    { name: "PlayStation 1", desc: t.ps1, keywords: "emulador ps1 online, jogos psx gratis, playstation 1 emulator pc, ps1 emulator android, pcsx2 alternatives, retroarch ps1, resident evil ps1 online, crash bandicoot ps1 browser" },
    { name: "Mega Drive", desc: t.megadrive, keywords: "jogar mega drive online, sega genesis gratis, genesis emulator online, sega saturn emulator, retroarch genesis, sonic mega drive online, mortal kombat sega emulator" },
    { name: "Nintendo 64", desc: t.n64, keywords: "jogos n64 online, n64 no navegador, n64 emulator pc, project64 online, n64 emulator android, retroarch n64, mario 64 online, zelda ocarina of time n64 emulator" },
    { name: "Nintendo DS", desc: t.nds, keywords: "jogos nintendo ds online, nds no navegador, nintendo ds emulator, nds emulator android, melonds online, retroarch nds, pokemon ds online, mario kart ds emulator online" },
    { name: "NES", desc: t.nes, keywords: "jogos nintendo antigo, nes online gratis, nes emulator online, mesen online, fceumm emulator, retroarch nes, super mario bros online nes, contra nes emulator" },
    { name: "RetroArch", desc: t.retroarch, keywords: "retroarch web emulator, multi console emulator, best retroarch cores, play retro games online browser, all in one emulator" },
    { name: "Multiplayer", desc: t.multiplayer, keywords: "online multiplayer retro games, play retro games with friends, p2p netplay emulator, multiplayer snes online, play ps1 with friends online" }
  ];

  const seoArticles = [
    { title: t.bestEmulators, content: "Descubra os melhores emuladores de 2026 para PC, Android e Navegador. Nossa plataforma utiliza tecnologia de ponta para garantir 60fps e baixo lag." },
    { title: t.howToPlay, content: "Aprenda como jogar clássicos do Super Nintendo e PlayStation no seu celular sem baixar nada. Compatível com controles bluetooth." },
    { title: t.legalSafe, content: "Jogar emuladores online no Sistema Fantasma é seguro e focado na preservação digital. Não hospedamos ROMs protegidas, use seus próprios backups." },
    { title: t.saveGames, content: "Nunca perca seu progresso. Com nosso sistema de Save State, você pode salvar em qualquer ponto do jogo e continuar depois." },
    { title: t.bestGraphics, content: "Experimente seus jogos favoritos com filtros HD, scanlines retro e upscaling para 4K diretamente no seu navegador." }
  ];

  return (
    <div className="min-h-screen bg-[#0a0a0f] text-white p-6 pb-24">
      <header className="max-w-4xl mx-auto text-center mb-12">
        <div className="flex justify-end mb-4">
          <Button onClick={() => setLang(lang === 'pt' ? 'en' : 'pt')} variant="outline" className="border-2 border-[#8B5CF6] text-[#8B5CF6] font-bold">
            <Languages className="mr-2 w-4 h-4" />
            {t.lang}
          </Button>
        </div>
        <motion.h1 
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="text-4xl md:text-6xl font-black italic text-[#8B5CF6] mb-4"
        >
          {t.title}
        </motion.h1>
        <p className="text-xl text-gray-400">
          {t.subtitle}
        </p>
      </header>

      <main className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {consoles.map((c, i) => (
          <motion.div
            key={c.name}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: i * 0.1 }}
            className="bg-[#1a1a24] p-6 rounded-lg border-8 border-black shadow-[10px_10px_0px_rgba(0,0,0,0.3)] hover:translate-y-[-5px] transition-transform"
          >
            <Gamepad2 className="w-16 h-16 text-[#FFFF00] mb-4" />
            <h2 className="text-2xl font-bold mb-2 uppercase">{c.name}</h2>
            <p className="text-gray-400 mb-4">{c.desc}</p>
            <div className="text-xs text-[#8B5CF6] font-mono opacity-50 mb-6">
              Tags: {c.keywords}
            </div>
            <Link href="/">
              <Button className="w-full bg-[#8B5CF6] hover:bg-[#7c3aed] text-white font-black py-8 rounded-none border-4 border-black shadow-[4px_4px_0px_white] active:shadow-none active:translate-x-[2px] active:translate-y-[2px]">
                {t.playNow}
              </Button>
            </Link>
          </motion.div>
        ))}
      </main>

      <section className="max-w-4xl mx-auto mt-16 p-8 bg-[#1a1a24] rounded-3xl border-4 border-white/10">
        <h2 className="text-3xl font-black mb-6 text-center">{t.whyTitle}</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="flex gap-4">
            <Zap className="w-8 h-8 text-[#FFFF00] shrink-0" />
            <div>
              <h3 className="font-bold mb-1">{t.noDownload}</h3>
              <p className="text-gray-400 text-sm">{t.noDownloadDesc}</p>
            </div>
          </div>
          <div className="flex gap-4">
            <Clock className="w-8 h-8 text-[#FFFF00] shrink-0" />
            <div>
              <h3 className="font-bold mb-1">{t.saveState}</h3>
              <p className="text-gray-400 text-sm">{t.saveStateDesc}</p>
            </div>
          </div>
          <div className="flex gap-4">
            <Users className="w-8 h-8 text-[#FFFF00] shrink-0" />
            <div>
              <h3 className="font-bold mb-1">{t.p2p}</h3>
              <p className="text-gray-400 text-sm">{t.p2pDesc}</p>
            </div>
          </div>
          <div className="flex gap-4">
            <Star className="w-8 h-8 text-[#FFFF00] shrink-0" />
            <div>
              <h3 className="font-bold mb-1">{t.free}</h3>
              <p className="text-gray-400 text-sm">{t.freeDesc}</p>
            </div>
          </div>
        </div>
      </section>

      <article className="max-w-4xl mx-auto mt-12 text-gray-500 text-sm leading-relaxed">
        <h3 className="font-bold mb-2 uppercase">{t.aboutTitle}</h3>
        <p className="mb-8">
          {t.aboutText}
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {seoArticles.map((art, idx) => (
            <div key={idx} className="p-4 bg-white/5 rounded-lg border border-white/10">
              <h4 className="font-bold text-white mb-2 uppercase text-xs">{art.title}</h4>
              <p className="text-xs opacity-70">{art.content}</p>
            </div>
          ))}
        </div>

        <div className="mt-8 pt-8 border-t border-white/10">
          <h4 className="font-bold text-white mb-4 uppercase">{t.consoleGuides}</h4>
          <div className="flex flex-wrap gap-2">
            {["RetroArch Setup", "Dolphin Emulator", "PCSX2 Online", "Yuzu Web", "Project64 Guide", "NDS Touch Control", "Netplay Multiplayer", "Cloud Save Retro", "Best Emulator Handheld 2026", "Play Retro Games on TV", "Low Lag Emulation"].map(tag => (
              <span key={tag} className="px-3 py-1 bg-white/5 rounded-full text-[10px] hover:bg-primary/20 cursor-pointer transition-colors">#{tag}</span>
            ))}
          </div>
        </div>
      </article>
    </div>
  );
}
