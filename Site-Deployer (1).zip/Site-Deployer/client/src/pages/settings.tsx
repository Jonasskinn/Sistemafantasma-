import { useQuery } from "@tanstack/react-query";
import { Gamepad2, Monitor, Wifi, Bluetooth, Settings, Ghost } from "lucide-react";
import { motion } from "framer-motion";
import { useState } from "react";

export default function SettingsPage() {
  const [controlsEnabled, setControlsEnabled] = useState(true);
  const [graphicsEnabled, setGraphicsEnabled] = useState(true);
  const [bluetoothEnabled, setBluetoothEnabled] = useState(false);

  return (
    <div style={{ backgroundColor: "#FF1493", minHeight: "100vh", color: "white", padding: "20px" }}>
      <header style={{ textAlign: "center", padding: "40px 0" }}>
        <motion.div 
          animate={{ rotate: [0, 360] }} 
          transition={{ duration: 10, repeat: Infinity, ease: "linear" }}
          style={{ backgroundColor: "white", width: "100px", height: "100px", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px", border: "6px solid black" }}
        >
          <Settings style={{ width: "50px", height: "50px", color: "#FF1493" }} />
        </motion.div>
        <h1 style={{ fontSize: "40px", fontWeight: "900", textShadow: "4px 4px 0px black" }}>CONFIGURAÇÕES</h1>
      </header>

      <div style={{ maxWidth: "500px", margin: "0 auto", display: "grid", gap: "20px" }}>
        <div style={{ backgroundColor: "white", padding: "30px", borderRadius: "40px", border: "8px solid #C71585" }}>
          <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
            <button 
              onClick={() => setControlsEnabled(!controlsEnabled)}
              style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "15px", backgroundColor: "#FFF0F5", borderRadius: "20px", border: "4px solid #FFB6C1", width: "100%", cursor: "pointer" }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "15px" }}>
                <Gamepad2 style={{ color: "#FF1493" }} />
                <span style={{ color: "#C71585", fontWeight: "900" }}>CONTROLES VIRTUAIS</span>
              </div>
              <div style={{ width: "60px", height: "30px", backgroundColor: controlsEnabled ? "#00FF00" : "#FF0000", borderRadius: "15px", border: "3px solid black", position: "relative" }}>
                <div style={{ width: "24px", height: "24px", backgroundColor: "white", borderRadius: "50%", position: "absolute", top: "0px", left: controlsEnabled ? "30px" : "0px", transition: "0.2s" }} />
              </div>
            </button>

            <button 
              onClick={() => setGraphicsEnabled(!graphicsEnabled)}
              style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "15px", backgroundColor: "#FFF0F5", borderRadius: "20px", border: "4px solid #FFB6C1", width: "100%", cursor: "pointer" }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "15px" }}>
                <Monitor style={{ color: "#FF1493" }} />
                <span style={{ color: "#C71585", fontWeight: "900" }}>QUALIDADE HD</span>
              </div>
              <div style={{ width: "60px", height: "30px", backgroundColor: graphicsEnabled ? "#00FF00" : "#FF0000", borderRadius: "15px", border: "3px solid black", position: "relative" }}>
                <div style={{ width: "24px", height: "24px", backgroundColor: "white", borderRadius: "50%", position: "absolute", top: "0px", left: graphicsEnabled ? "30px" : "0px", transition: "0.2s" }} />
              </div>
            </button>

            <button 
              onClick={() => setBluetoothEnabled(!bluetoothEnabled)}
              style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "15px", backgroundColor: "#FFF0F5", borderRadius: "20px", border: "4px solid #FFB6C1", width: "100%", cursor: "pointer" }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "15px" }}>
                <Bluetooth style={{ color: "#FF1493" }} />
                <span style={{ color: "#C71585", fontWeight: "900" }}>BLUETOOTH</span>
              </div>
              <div style={{ width: "60px", height: "30px", backgroundColor: bluetoothEnabled ? "#00FF00" : "#FF0000", borderRadius: "15px", border: "3px solid black", position: "relative" }}>
                <div style={{ width: "24px", height: "24px", backgroundColor: "white", borderRadius: "50%", position: "absolute", top: "0px", left: bluetoothEnabled ? "30px" : "0px", transition: "0.2s" }} />
              </div>
            </button>
          </div>
        </div>

        <div style={{ textAlign: "center", padding: "20px" }}>
          <p style={{ fontWeight: "900", fontSize: "14px" }}>VERSÃO GHOST 1.0.4</p>
        </div>
      </div>
    </div>
  );
}
