import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { X, Ghost } from "lucide-react";
import { motion } from "framer-motion";

interface EmulatorPlayerProps {
  romUrl: string;
  romName: string;
  core: string;
  onClose: () => void;
}

declare global {
  interface Window {
    EJS_player: string;
    EJS_core: string;
    EJS_gameUrl: string;
    EJS_pathtodata: string;
    EJS_gameName: string;
    EJS_color: string;
    EJS_volume: number;
    EJS_language: string;
    EJS_startOnLoaded: boolean;
    EJS_mouse: boolean;
    EJS_touch: boolean;
    EJS_DS_touch_mode: boolean;
    EJS_onGameStart: () => void;
    EJS_onSaveState: () => void;
    EJS_onLoadState: () => void;
  }
}

export function detectCore(filename: string): string {
  const name = filename.toLowerCase();
  const ext = filename.split(".").pop()?.toLowerCase() || "";

  const CORE_MAP: Record<string, string> = {
    nes: "nes",
    snes: "snes",
    gb: "gb",
    gbc: "gbc",
    gba: "gba",
    n64: "n64",
    nds: "nds",
    ds: "nds",
    psx: "psx",
    bin: "psx",
    cue: "psx",
    iso: "psx",
    md: "segaMD",
    gen: "segaMD",
    sms: "segaMS",
    gg: "segaGG",
    "32x": "sega32x",
    a26: "atari2600",
    a78: "atari7800",
    smc: "snes",
    sfc: "snes",
    z64: "n64",
    v64: "n64",
    zip: "gba", 
    "7z": "psx",
  };

  if (ext === "nes") return "nes";
  if (ext === "smc" || ext === "sfc") return "snes";
  if (ext === "gba") return "gba";
  if (ext === "gb") return "gb";
  if (ext === "gbc") return "gbc";
  if (ext === "z64" || ext === "n64" || ext === "v64") return "n64";
  if (ext === "bin" || ext === "iso" || ext === "cue" || ext === "img") return "psx";
  if (ext === "7z" && (name.includes("ps1") || name.includes("psx"))) return "psx";
  
  return CORE_MAP[ext] || "nes";
}

export function EmulatorPlayer({ romUrl, romName, core, onClose }: EmulatorPlayerProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    if (!containerRef.current) return;

    // BLOQUEIO DE MOVIMENTAÇÃO (Permitindo touch para o emulador)
    document.body.style.overflow = "hidden";
    document.body.style.position = "fixed";
    document.body.style.width = "100%";
    document.body.style.height = "100%";
    // Removido touchAction: none para permitir interação com o DS

    const gameDiv = document.getElementById("emulator-game");
    if (gameDiv) {
      gameDiv.innerHTML = "";
    }

    window.EJS_player = "#emulator-game";
    window.EJS_core = core;
    window.EJS_gameUrl = romUrl;
    window.EJS_pathtodata = "https://cdn.emulatorjs.org/stable/data/";
    
    // Configurações para HOSPEDAGEM LOCAL
    window.EJS_startOnLoaded = true;
    window.EJS_DEBUG_XX = true;
    window.EJS_loadStateURL = "";
    window.EJS_language = "pt-BR";
    window.EJS_core = core;
    
    // Se a URL for relativa, ela está sendo servida pelo Replit diretamente.
    // Isso ELIMINA o erro de rede (CORS).
    if (romUrl.startsWith("/")) {
        window.EJS_gameUrl = window.location.origin + romUrl;
    }
    window.EJS_gameName = romName;
    window.EJS_color = "#8B5CF6";
    window.EJS_volume = 0.7;
    window.EJS_language = "pt-BR";
    window.EJS_startOnLoaded = true;
    window.EJS_mouse = true;
    window.EJS_touch = true;
    window.EJS_DS_touch_mode = true;
    
    // Adicionando configurações para evitar erro de rede e melhorar compatibilidade
    window.EJS_DEBUG_XX = true;
    // Forçar uso de proxy CORS caso o servidor de ROM não permita acesso direto
    if (!romUrl.includes(window.location.origin)) {
      window.EJS_gameUrl = romUrl;
    }
    window.EJS_onGameStart = () => {
      setIsLoaded(true);
    };

    // Abre anúncio antes de carregar o script do emulador
    window.open("https://otieu.com/4/10402648", "_blank");

    const script = document.createElement("script");
    script.src = "https://cdn.emulatorjs.org/stable/data/loader.js";
    document.body.appendChild(script);

    return () => {
      document.body.style.overflow = "";
      document.body.style.position = "";
      document.body.style.width = "";
      document.body.style.height = "";
      
      if (document.body.contains(script)) {
        document.body.removeChild(script);
      }
      const div = document.getElementById("emulator-game");
      if (div) {
        div.innerHTML = "";
      }
    };
  }, [romUrl, romName, core]);

  return (
    <div 
      ref={containerRef}
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        zIndex: 99999,
        backgroundColor: "black",
        display: "flex",
        flexDirection: "column",
        overflow: "hidden"
      }}
    >
      <div style={{ width: "100%", padding: "10px", display: "flex", alignItems: "center", justifyContent: "space-between", backgroundColor: "#8B5CF6", borderBottom: "4px solid black", zIndex: 100000 }}>
        <h3 style={{ margin: 0, color: "white", fontSize: "18px", fontWeight: "900" }}>{romName}</h3>
        <Button onClick={onClose} style={{ backgroundColor: "#BAE6FD", color: "black", height: "40px", width: "40px", borderRadius: "10px", fontWeight: "900", border: "3px solid black" }}><X /></Button>
      </div>
      
      <div style={{ flex: 1, width: "100%", height: "100%", position: "relative", backgroundColor: "black", overflow: "hidden" }}>
        <div 
          id="emulator-game" 
          style={{ 
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%", 
            height: "100%",
            backgroundColor: "black",
            touchAction: "auto"
          }}
        />
      </div>
    </div>
  );
}
