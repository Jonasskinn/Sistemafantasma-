# Sistema Fantasma - Retro Emulator P2P

## Overview

Sistema Fantasma is a distributed retro game emulator system that enables P2P gaming across multiple devices on the same network. The application transforms game ROMs into "ghost data" bundles that can be distributed and processed across connected peers, simulating a virtual gaming PC through network collaboration. It supports various retro console formats (NES, SNES, Game Boy, PlayStation, etc.) and includes WebRTC-based peer-to-peer networking for real-time synchronization.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack React Query for server state and caching
- **UI Components**: Radix UI primitives with shadcn/ui component library
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **Animations**: Framer Motion for UI transitions
- **Build Tool**: Vite with HMR support

### Backend Architecture
- **Runtime**: Node.js with Express
- **API Pattern**: RESTful endpoints under `/api/*`
- **WebSocket**: Native `ws` library for Ghost Network signaling server at `/ghost` path
- **Storage**: In-memory storage implementation (MemStorage class) with Drizzle ORM schema definitions ready for PostgreSQL migration
- **File Handling**: Multer for ROM file uploads to `/tmp/roms`

### Ghost Network (P2P System)
- **Signaling Server**: WebSocket-based peer discovery and coordination
- **Peer Connections**: WebRTC for direct P2P data channels
- **Data Distribution**: Games transformed into "Ghost Bundles" - chunked, hashed data packets
- **Integrity**: SHA-256 hashing with Merkle root verification
- **Distributed Processing**: Role-based system (master, compute, storage, display) for task distribution

### Emulation Layer
- **Emulator**: EmulatorJS integration for browser-based ROM execution
- **Supported Cores**: NES, SNES, GB, GBC, GBA, N64, NDS, PSX, Sega Genesis/MD, SMS, Game Gear, Atari
- **ROM Storage**: IndexedDB for client-side ROM persistence

### Mobile Support
- **Capacitor**: Configured for Android deployment (app ID: com.retroghost.app)
- **Build Output**: `dist/public` for web assets

### Data Flow
1. User uploads ROM file → stored in IndexedDB
2. ROM transformed into Ghost Bundles (256KB chunks with hashes)
3. Ghost Network distributes bundles across connected peers
4. EmulatorJS loads and runs the game in browser
5. Game state synchronized via WebRTC data channels

## External Dependencies

### Core Services
- **Database**: Drizzle ORM with PostgreSQL schema (connect-pg-simple for sessions) - currently using in-memory storage
- **Real-time**: WebSocket (ws) for signaling, WebRTC for P2P connections

### Third-Party APIs
- **Stripe**: Payment integration via @stripe/stripe-js (publishable key in VITE_STRIPE_PUBLISHABLE_KEY)
- **EmulatorJS**: External CDN for retro game emulation cores

### Storage
- **IndexedDB**: Client-side ROM and game data persistence
- **IPFS/Kubo**: Planned for distributed asset storage (referenced in design docs)

### Build & Development
- **Vite**: Development server with HMR on port 5000
- **Replit Cartographer**: Vite plugin for Replit integration
- **TypeScript**: Strict mode with path aliases (@/, @shared/, @assets/)